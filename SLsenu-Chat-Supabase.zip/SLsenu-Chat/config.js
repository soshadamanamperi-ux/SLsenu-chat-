// Put your Supabase Project URL and publishable (or legacy anon) key here.
// Safe for browser use only when Row Level Security is enabled.
// NEVER put a service_role / secret key in this file.
window.SUPABASE_CONFIG = {
  url: "YOUR_SUPABASE_PROJECT_URL",
  anonKey: "YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY"
};
