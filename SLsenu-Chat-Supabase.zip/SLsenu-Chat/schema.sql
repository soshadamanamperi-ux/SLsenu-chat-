-- SLsenu Chat database schema
-- Run the whole file in Supabase Dashboard -> SQL Editor -> New query.
-- Re-running is not guaranteed to be harmless: this is an initial setup script.

create extension if not exists pgcrypto;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique check (username ~ '^[a-zA-Z0-9_]{3,24}$'),
  display_name text not null default 'SLsenu user' check (char_length(display_name) between 1 and 40),
  created_at timestamptz not null default now()
);

create table public.conversations (
  id uuid primary key default gen_random_uuid(),
  type text not null check (type in ('direct', 'group')),
  title text,
  created_by uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  constraint group_title_required check (
    (type = 'direct' and title is null) or
    (type = 'group' and title is not null and char_length(trim(title)) between 1 and 60)
  )
);

create table public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'member' check (role in ('owner', 'member')),
  joined_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);

create table public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  content text not null check (char_length(trim(content)) between 1 and 4000),
  created_at timestamptz not null default now()
);

create index conversation_members_user_idx on public.conversation_members(user_id);
create index messages_conversation_created_idx on public.messages(conversation_id, created_at);

-- Create a profile row automatically when Supabase Auth creates a user.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  base_name text;
  chosen_name text;
begin
  base_name := lower(regexp_replace(coalesce(new.raw_user_meta_data ->> 'username', ''), '[^a-zA-Z0-9_]', '', 'g'));
  if char_length(base_name) < 3 then
    base_name := 'user_' || left(new.id::text, 8);
  end if;
  base_name := left(base_name, 19);
  chosen_name := base_name;
  if exists (select 1 from public.profiles p where p.username = chosen_name) then
    chosen_name := left(base_name, 19) || '_' || left(new.id::text, 4);
  end if;

  insert into public.profiles (id, username, display_name)
  values (
    new.id,
    chosen_name,
    coalesce(nullif(left(trim(new.raw_user_meta_data ->> 'display_name'), 40), ''), chosen_name)
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_profile on auth.users;
create trigger on_auth_user_created_profile
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Helper function: SECURITY DEFINER avoids recursive RLS evaluation on memberships.
create or replace function public.is_conversation_member(_conversation_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.conversation_members cm
    where cm.conversation_id = _conversation_id
      and cm.user_id = (select auth.uid())
  );
$$;

revoke all on function public.is_conversation_member(uuid) from public;
grant execute on function public.is_conversation_member(uuid) to authenticated;

-- Create the conversation and its memberships atomically.
-- Clients cannot directly add themselves to an existing conversation.
create or replace function public.create_conversation(
  _type text,
  _title text,
  _member_ids uuid[]
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  new_conversation_id uuid;
  member_ids uuid[];
  member_count integer;
begin
  if (select auth.uid()) is null then
    raise exception 'You must be signed in.';
  end if;

  if _type not in ('direct', 'group') then
    raise exception 'Invalid conversation type.';
  end if;

  select array_agg(distinct candidate_id)
    into member_ids
  from unnest(coalesce(_member_ids, array[]::uuid[]) || array[(select auth.uid())]) as t(candidate_id)
  where candidate_id is not null;

  member_count := coalesce(cardinality(member_ids), 0);

  if _type = 'direct' and member_count <> 2 then
    raise exception 'A private chat must have exactly two members.';
  end if;

  if _type = 'group' and (member_count < 2 or member_count > 50) then
    raise exception 'A group must have between 2 and 50 members.';
  end if;

  if _type = 'group' and (_title is null or char_length(trim(_title)) not between 1 and 60) then
    raise exception 'Group name must be between 1 and 60 characters.';
  end if;

  -- Only allow existing auth users as members.
  if (select count(*) from auth.users u where u.id = any(member_ids)) <> member_count then
    raise exception 'One or more selected users do not exist.';
  end if;

  insert into public.conversations(type, title, created_by)
  values (_type, case when _type = 'group' then trim(_title) else null end, (select auth.uid()))
  returning id into new_conversation_id;

  insert into public.conversation_members(conversation_id, user_id, role)
  select new_conversation_id, member_id,
         case when member_id = (select auth.uid()) then 'owner' else 'member' end
  from unnest(member_ids) as t(member_id);

  return new_conversation_id;
end;
$$;

revoke all on function public.create_conversation(text, text, uuid[]) from public;
grant execute on function public.create_conversation(text, text, uuid[]) to authenticated;

-- Enable RLS on every table exposed through the API.
alter table public.profiles enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;

-- Explicit privileges: no unauthenticated database access.
revoke all on table public.profiles from anon, authenticated;
revoke all on table public.conversations from anon, authenticated;
revoke all on table public.conversation_members from anon, authenticated;
revoke all on table public.messages from anon, authenticated;

grant select on table public.profiles to authenticated;
grant select on table public.conversations to authenticated;
grant select on table public.conversation_members to authenticated;
grant select, insert on table public.messages to authenticated;

-- User directory reveals only username/display name, never email addresses.
create policy "Signed in users can view usernames"
on public.profiles for select to authenticated
using (true);

create policy "Members can view their conversations"
on public.conversations for select to authenticated
using ((select public.is_conversation_member(id)));

create policy "Members can view memberships in their conversations"
on public.conversation_members for select to authenticated
using ((select public.is_conversation_member(conversation_id)));

create policy "Members can read conversation messages"
on public.messages for select to authenticated
using ((select public.is_conversation_member(conversation_id)));

create policy "Users can send as themselves to conversations they belong to"
on public.messages for insert to authenticated
with check (
  sender_id = (select auth.uid())
  and (select public.is_conversation_member(conversation_id))
  and char_length(trim(content)) between 1 and 4000
);

-- Enable Realtime for messages. Supabase projects normally already have this publication.
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime')
     and not exists (
       select 1 from pg_publication_tables
       where pubname = 'supabase_realtime'
         and schemaname = 'public'
         and tablename = 'messages'
     ) then
    alter publication supabase_realtime add table public.messages;
  end if;
end $$;
