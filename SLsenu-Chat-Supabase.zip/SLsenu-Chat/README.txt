SLsenu Chat — Real-time private + group chat (Supabase)

FILES
- index.html: page structure
- style.css: dark responsive UI
- config.js: your Supabase project URL and publishable/anon key
- app.js: email/password auth, user search, private chat, group creation, realtime messages
- schema.sql: database tables, RLS security policies, safe conversation-creation function, realtime publication
- README.txt: setup steps

IMPORTANT SECURITY NOTES
- Never put a Supabase service_role/secret key in browser code. Use only the project's publishable key (or legacy anon key).
- Keep the RLS policies in schema.sql. Do not turn off RLS to fix errors.
- The user directory exposes only usernames/display names, not email addresses.
- Private messages are readable only by members of that conversation under the included RLS policies.
- This is a starter implementation. It has no end-to-end encryption, report/block tools, moderation, or invitation/leave-group management. Do not use it to share highly sensitive information.

SETUP (free tier availability and limits may change)
1. Go to https://supabase.com/ and create a project. Keep its database password private.
2. In the Supabase dashboard, open SQL Editor -> New query. Copy all of schema.sql into the editor and Run it.
3. In Project Settings -> API (or the project's Connect/API section), copy the Project URL and the publishable key. If your dashboard shows the legacy anon key instead, that can be used too.
4. Open config.js and replace:
   YOUR_SUPABASE_PROJECT_URL
   YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY
   with the values from your own project. Do not use a service_role or secret key.
5. In Supabase Authentication settings, enable Email provider. For real use, keep email confirmation enabled. Add your local test URL and the final published URL under allowed Site URL / Redirect URLs.
6. Open the website through a local web server or publish the files; do not rely on file:// if browser modules/network security gets in the way.
7. Sign up with a valid email, username (3–24 letters/numbers/underscores), and password of at least 8 characters. Confirm your email if asked, then log in.
8. Open a second browser/profile or use a second test account to verify private chat and group chat between accounts.
9. In Database -> Publications / Realtime settings, ensure `public.messages` is included in the `supabase_realtime` publication. schema.sql tries to add it automatically if the publication exists.
10. Publish the static files to GitHub Pages or another static host. After publishing, add the exact published URL to Supabase Auth redirect URLs.

GITHUB PAGES
1. Create a repository, e.g. slsenu-chat.
2. Upload index.html, style.css, config.js, app.js (and optionally README.txt). schema.sql is a setup file, not a website page.
3. Settings -> Pages -> Deploy from a branch -> main -> /(root) -> Save.
4. Open the published URL shown in GitHub Pages. Update Supabase Auth allowed redirect URLs with this URL.

TROUBLESHOOTING
- "Setup needed": config.js still contains placeholder values.
- Signup does not open the app immediately: email confirmation may be enabled. Confirm email and log in.
- Profile not found: check that schema.sql ran successfully and the on_auth_user_created_profile trigger exists. For accounts created before the trigger, delete only test accounts or create their profile through a trusted admin process; do not weaken RLS.
- Messages don't update live: confirm `messages` is in `supabase_realtime`, check browser console, and verify RLS policies.
- Do not paste project secrets, passwords, or private user data into public chat or code repositories.
