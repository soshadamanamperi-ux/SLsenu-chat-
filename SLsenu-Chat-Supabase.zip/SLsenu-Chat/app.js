(() => {
  const cfg = window.SUPABASE_CONFIG || {};
  const statusEl = document.getElementById('connectionStatus');
  const authScreen = document.getElementById('authScreen');
  const chatApp = document.getElementById('chatApp');
  const authForm = document.getElementById('authForm');
  const authMessage = document.getElementById('authMessage');
  const usernameWrap = document.getElementById('usernameWrap');
  const usernameInput = document.getElementById('username');
  const authSubmit = document.getElementById('authSubmit');
  const logoutBtn = document.getElementById('logoutBtn');
  const userSearch = document.getElementById('userSearch');
  const userResults = document.getElementById('userResults');
  const conversationList = document.getElementById('conversationList');
  const emptyChat = document.getElementById('emptyChat');
  const activeChat = document.getElementById('activeChat');
  const messagesEl = document.getElementById('messages');
  const sendForm = document.getElementById('sendForm');
  const messageInput = document.getElementById('messageInput');
  const groupModal = document.getElementById('groupModal');
  const groupForm = document.getElementById('groupForm');
  const groupMembersInput = document.getElementById('groupMembers');
  const groupUserList = document.getElementById('groupUserList');
  const groupMessage = document.getElementById('groupMessage');
  const toastEl = document.getElementById('toast');

  let supabase = null;
  let currentUser = null;
  let currentProfile = null;
  let profiles = [];
  let conversations = [];
  let selectedConversation = null;
  let selectedMembers = new Set();
  let messageChannel = null;
  let authMode = 'login';
  let toastTimer = null;

  function escapeText(value) {
    return String(value ?? '');
  }
  function toast(message) {
    toastEl.textContent = message;
    toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove('show'), 3200);
  }
  function setConnection(text, connected = false) {
    statusEl.textContent = '';
    const dot = document.createElement('i');
    statusEl.append(dot, document.createTextNode(' ' + text));
    statusEl.classList.toggle('connected', connected);
  }
  function showError(error, context = '') {
    console.error(context, error);
    const detail = error?.message || String(error || 'Unknown error');
    toast(context ? `${context}: ${detail}` : detail);
  }
  function initials(name) {
    const value = (name || 'S').trim();
    return value.slice(0, 1).toUpperCase();
  }
  function timeLabel(dateString) {
    const d = new Date(dateString);
    if (Number.isNaN(d.getTime())) return '';
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }
  function safeUsername(profile) {
    return profile?.display_name || profile?.username || 'User';
  }

  if (!cfg.url || !cfg.anonKey || cfg.url.includes('YOUR_SUPABASE') || cfg.anonKey.includes('YOUR_SUPABASE')) {
    setConnection('Add Supabase config');
    authMessage.textContent = 'Setup needed: add your Supabase Project URL and publishable/anon key in config.js first.';
    authSubmit.disabled = true;
    authSubmit.style.opacity = '.5';
    return;
  }

  supabase = window.supabase.createClient(cfg.url, cfg.anonKey, {
    auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
  });
  setConnection('Connecting…');

  document.querySelectorAll('[data-auth-mode]').forEach(button => {
    button.addEventListener('click', () => setAuthMode(button.dataset.authMode));
  });

  function setAuthMode(mode) {
    authMode = mode;
    document.querySelectorAll('[data-auth-mode]').forEach(button => button.classList.toggle('active', button.dataset.authMode === mode));
    const signup = mode === 'signup';
    usernameWrap.hidden = !signup;
    usernameInput.required = signup;
    document.getElementById('password').autocomplete = signup ? 'new-password' : 'current-password';
    authSubmit.innerHTML = signup ? 'Create account <span>↗</span>' : 'Log in <span>↗</span>';
    authMessage.textContent = '';
  }

  authForm.addEventListener('submit', async event => {
    event.preventDefault();
    if (!supabase) return;
    authSubmit.disabled = true;
    authMessage.textContent = authMode === 'signup' ? 'Creating your account…' : 'Logging in…';
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    try {
      if (authMode === 'signup') {
        const username = usernameInput.value.trim().toLowerCase();
        if (!/^[a-z0-9_]{3,24}$/.test(username)) {
          throw new Error('Username එක අකුරු 3–24 අතර විය යුතුයි. English letters, numbers, _ පමණක් භාවිත කරන්න.');
        }
        const { data, error } = await supabase.auth.signUp({
          email, password,
          options: { data: { username, display_name: username }, emailRedirectTo: window.location.href.split('#')[0] }
        });
        if (error) throw error;
        if (!data.session) {
          authMessage.textContent = 'Signup request එක සාර්ථකයි. Email confirmation අවශ්‍ය නම් email එකේ link එක ඔබලා පසුව log in වෙන්න.';
        } else {
          authMessage.textContent = 'Account created! Loading your chats…';
        }
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        authMessage.textContent = 'Logged in. Loading…';
      }
      document.getElementById('password').value = '';
    } catch (error) {
      authMessage.textContent = error.message || 'Could not authenticate.';
    } finally {
      authSubmit.disabled = false;
    }
  });

  logoutBtn.addEventListener('click', async () => {
    await cleanupRealtime();
    const { error } = await supabase.auth.signOut();
    if (error) showError(error, 'Log out failed');
    else toast('Logged out.');
  });

  async function handleSession(session) {
    currentUser = session?.user || null;
    if (!currentUser) {
      await cleanupRealtime();
      currentProfile = null;
      profiles = [];
      conversations = [];
      selectedConversation = null;
      authScreen.hidden = false;
      chatApp.hidden = true;
      logoutBtn.hidden = true;
      setConnection('Signed out');
      return;
    }
    authScreen.hidden = true;
    chatApp.hidden = false;
    logoutBtn.hidden = false;
    setConnection('Connected', true);
    await loadProfiles();
    currentProfile = profiles.find(p => p.id === currentUser.id) || {
      id: currentUser.id,
      username: currentUser.user_metadata?.username || currentUser.email?.split('@')[0] || 'user',
      display_name: currentUser.user_metadata?.display_name || 'SLsenu user'
    };
    document.getElementById('myName').textContent = '@' + currentProfile.username;
    document.getElementById('myAvatar').textContent = initials(currentProfile.username);
    renderUserResults(userSearch.value);
    await loadConversations();
  }

  supabase.auth.onAuthStateChange((_event, session) => {
    // Defer database work to avoid blocking Supabase Auth's callback.
    setTimeout(() => handleSession(session).catch(error => showError(error, 'Loading account failed')), 0);
  });
  supabase.auth.getSession().then(({ data, error }) => {
    if (error) showError(error, 'Session check failed');
    handleSession(data?.session).catch(error => showError(error, 'Loading account failed'));
  });

  async function loadProfiles() {
    const { data, error } = await supabase.from('profiles')
      .select('id, username, display_name')
      .order('username')
      .limit(500);
    if (error) throw error;
    profiles = data || [];
  }

  async function loadConversations() {
    const { data, error } = await supabase.from('conversation_members')
      .select('conversation_id, user_id, role, conversations(id, type, title, created_by, created_at)')
      .eq('user_id', currentUser.id)
      .order('joined_at', { ascending: false });
    if (error) throw error;
    const base = (data || []).map(row => row.conversations).filter(Boolean);
    const unique = [...new Map(base.map(c => [c.id, c])).values()];
    const ids = unique.map(c => c.id);
    let members = [];
    if (ids.length) {
      const result = await supabase.from('conversation_members').select('conversation_id,user_id,role').in('conversation_id', ids);
      if (result.error) throw result.error;
      members = result.data || [];
    }
    conversations = unique.map(c => ({ ...c, members: members.filter(m => m.conversation_id === c.id) }))
      .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    renderConversations();
  }

  function conversationLabel(conversation) {
    if (conversation.type === 'group') return conversation.title || 'Untitled group';
    const other = conversation.members.find(m => m.user_id !== currentUser.id);
    const profile = profiles.find(p => p.id === other?.user_id);
    return profile ? '@' + profile.username : 'Private chat';
  }
  function conversationSubLabel(conversation) {
    return conversation.type === 'group'
      ? `${conversation.members.length} members · Group`
      : 'Private conversation';
  }
  function renderConversations() {
    conversationList.replaceChildren();
    if (!conversations.length) {
      const p = document.createElement('p');
      p.className = 'empty-note';
      p.textContent = 'No chats yet. Find a username to start one.';
      conversationList.append(p);
      return;
    }
    conversations.forEach(conversation => {
      const button = document.createElement('button');
      button.className = 'conversation-item' + (selectedConversation?.id === conversation.id ? ' active' : '');
      button.type = 'button';
      const avatar = document.createElement('span');
      avatar.className = 'avatar';
      avatar.textContent = initials(conversationLabel(conversation).replace('@', ''));
      const info = document.createElement('span');
      info.className = 'conversation-info';
      const title = document.createElement('strong');
      title.textContent = conversationLabel(conversation);
      const sub = document.createElement('span');
      sub.textContent = conversationSubLabel(conversation);
      info.append(title, sub);
      button.append(avatar, info);
      button.addEventListener('click', () => openConversation(conversation.id));
      conversationList.append(button);
    });
  }

  userSearch.addEventListener('input', () => renderUserResults(userSearch.value));
  function renderUserResults(query) {
    userResults.replaceChildren();
    const q = (query || '').trim().replace(/^@/, '').toLowerCase();
    if (!currentUser || !q) {
      userResults.hidden = true;
      return;
    }
    const matches = profiles.filter(p => p.id !== currentUser.id && p.username.toLowerCase().includes(q)).slice(0, 12);
    userResults.hidden = false;
    if (!matches.length) {
      const p = document.createElement('p');
      p.className = 'empty-note';
      p.textContent = 'No matching usernames.';
      userResults.append(p);
      return;
    }
    matches.forEach(profile => {
      const button = document.createElement('button');
      button.className = 'user-result';
      button.type = 'button';
      const avatar = document.createElement('span');
      avatar.className = 'avatar';
      avatar.textContent = initials(profile.username);
      const label = document.createElement('strong');
      label.textContent = '@' + profile.username;
      button.append(avatar, label);
      button.addEventListener('click', () => startDirectChat(profile));
      userResults.append(button);
    });
  }

  async function startDirectChat(profile) {
    try {
      toast('Opening private chat…');
      // Reuse an existing direct conversation if these are exactly its two members.
      const existing = conversations.find(c => c.type === 'direct' && c.members.length === 2 &&
        c.members.some(m => m.user_id === profile.id) && c.members.some(m => m.user_id === currentUser.id));
      let conversationId = existing?.id;
      if (!conversationId) {
        const { data, error } = await supabase.rpc('create_conversation', {
          _type: 'direct', _title: null, _member_ids: [profile.id]
        });
        if (error) throw error;
        conversationId = data;
      }
      userSearch.value = '';
      renderUserResults('');
      await loadConversations();
      await openConversation(conversationId);
    } catch (error) {
      showError(error, 'Could not open private chat');
    }
  }

  document.getElementById('newGroupBtn').addEventListener('click', openGroupModal);
  document.getElementById('emptyGroupBtn').addEventListener('click', openGroupModal);
  document.getElementById('closeGroupBtn').addEventListener('click', closeGroupModal);
  groupModal.querySelector('[data-close-group]').addEventListener('click', closeGroupModal);
  function openGroupModal() {
    selectedMembers = new Set();
    groupForm.reset();
    groupMessage.textContent = '';
    renderGroupUsers('');
    groupModal.hidden = false;
    groupMembersInput.focus();
  }
  function closeGroupModal() { groupModal.hidden = true; }
  groupMembersInput.addEventListener('input', () => renderGroupUsers(groupMembersInput.value));
  function renderGroupUsers(query) {
    groupUserList.replaceChildren();
    const q = (query || '').trim().replace(/^@/, '').toLowerCase();
    const matches = profiles.filter(p => p.id !== currentUser?.id && (!q || p.username.toLowerCase().includes(q))).slice(0, 50);
    if (!matches.length) {
      const p = document.createElement('p');
      p.className = 'tiny muted';
      p.textContent = 'No users found.';
      groupUserList.append(p);
      return;
    }
    matches.forEach(profile => {
      const label = document.createElement('label');
      label.className = 'group-user';
      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.checked = selectedMembers.has(profile.id);
      checkbox.addEventListener('change', () => {
        if (checkbox.checked) selectedMembers.add(profile.id);
        else selectedMembers.delete(profile.id);
      });
      const avatar = document.createElement('span');
      avatar.className = 'avatar';
      avatar.textContent = initials(profile.username);
      const name = document.createElement('strong');
      name.textContent = '@' + profile.username;
      label.append(checkbox, avatar, name);
      groupUserList.append(label);
    });
  }

  groupForm.addEventListener('submit', async event => {
    event.preventDefault();
    const title = document.getElementById('groupName').value.trim();
    if (selectedMembers.size < 1) {
      groupMessage.textContent = 'Group එකට අවම වශයෙන් තවත් එක් කෙනෙක් තෝරන්න.';
      return;
    }
    if (selectedMembers.size > 49) {
      groupMessage.textContent = 'Group එකකට ඔයා ඇතුළුව උපරිම 50 දෙනෙක් පමණයි.';
      return;
    }
    const submit = groupForm.querySelector('button[type="submit"]');
    submit.disabled = true;
    try {
      const { data, error } = await supabase.rpc('create_conversation', {
        _type: 'group', _title: title, _member_ids: [...selectedMembers]
      });
      if (error) throw error;
      closeGroupModal();
      await loadConversations();
      await openConversation(data);
      toast('Group created.');
    } catch (error) {
      groupMessage.textContent = error.message || 'Could not create group.';
    } finally {
      submit.disabled = false;
    }
  });

  async function openConversation(id) {
    const conversation = conversations.find(c => c.id === id);
    if (!conversation) {
      await loadConversations();
    }
    selectedConversation = conversations.find(c => c.id === id);
    if (!selectedConversation) throw new Error('Conversation not found or you are not a member.');
    renderConversations();
    emptyChat.hidden = true;
    activeChat.hidden = false;
    document.getElementById('chatTitle').textContent = conversationLabel(selectedConversation);
    document.getElementById('chatSubtitle').textContent = conversationSubLabel(selectedConversation);
    document.getElementById('chatAvatar').textContent = initials(conversationLabel(selectedConversation).replace('@', ''));
    await loadMessages(id);
    await subscribeToMessages(id);
  }

  async function loadMessages(conversationId) {
    messagesEl.replaceChildren();
    const { data, error } = await supabase.from('messages')
      .select('id,conversation_id,sender_id,content,created_at')
      .eq('conversation_id', conversationId)
      .order('created_at', { ascending: true })
      .limit(300);
    if (error) throw error;
    (data || []).forEach(renderMessage);
    scrollMessagesToBottom();
  }

  function renderMessage(message) {
    if (messagesEl.querySelector(`[data-message-id="${CSS.escape(message.id)}"]`)) return;
    const mine = message.sender_id === currentUser.id;
    const profile = profiles.find(p => p.id === message.sender_id);
    const row = document.createElement('div');
    row.className = 'message-row' + (mine ? ' mine' : '');
    row.dataset.messageId = message.id;
    const avatar = document.createElement('span');
    avatar.className = 'message-avatar';
    avatar.textContent = initials(profile?.username || 'S');
    const body = document.createElement('div');
    body.className = 'message-body';
    if (selectedConversation?.type === 'group' && !mine) {
      const sender = document.createElement('p');
      sender.className = 'message-sender';
      sender.textContent = '@' + (profile?.username || 'user');
      body.append(sender);
    }
    const bubble = document.createElement('div');
    bubble.className = 'bubble';
    bubble.textContent = message.content;
    const time = document.createElement('p');
    time.className = 'message-time';
    time.textContent = timeLabel(message.created_at);
    body.append(bubble, time);
    row.append(avatar, body);
    messagesEl.append(row);
  }
  function scrollMessagesToBottom() { messagesEl.scrollTop = messagesEl.scrollHeight; }

  async function subscribeToMessages(conversationId) {
    await cleanupRealtime();
    messageChannel = supabase.channel('chat-' + conversationId + '-' + currentUser.id)
      .on('postgres_changes', {
        event: 'INSERT', schema: 'public', table: 'messages',
        filter: 'conversation_id=eq.' + conversationId
      }, payload => {
        if (selectedConversation?.id !== conversationId) return;
        renderMessage(payload.new);
        scrollMessagesToBottom();
      })
      .subscribe((status, error) => {
        if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
          console.warn('Realtime subscription status:', status, error);
          toast('Realtime connection issue. Check Supabase Realtime setup.');
        }
      });
  }
  async function cleanupRealtime() {
    if (messageChannel && supabase) {
      await supabase.removeChannel(messageChannel);
      messageChannel = null;
    }
  }

  sendForm.addEventListener('submit', async event => {
    event.preventDefault();
    if (!selectedConversation || !currentUser) return;
    const content = messageInput.value.trim();
    if (!content) return;
    const sendButton = sendForm.querySelector('button');
    sendButton.disabled = true;
    try {
      const { error } = await supabase.from('messages').insert({
        conversation_id: selectedConversation.id,
        sender_id: currentUser.id,
        content
      });
      if (error) throw error;
      messageInput.value = '';
      messageInput.focus();
    } catch (error) {
      showError(error, 'Message not sent');
    } finally {
      sendButton.disabled = false;
    }
  });
})();
